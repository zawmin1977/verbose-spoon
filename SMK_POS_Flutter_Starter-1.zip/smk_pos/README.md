# SMK POS — Flutter starter

မြန်မာဘာသာသုံး အဝတ်အထည်ဆိုင် POS starter project ဖြစ်ပါတယ်။

## ပါဝင်ပြီးသော အခြေခံလုပ်ဆောင်ချက်များ
- မြန်မာဘာသာ UI
- ပစ္စည်းအမည်၊ ရောင်းဈေး၊ အရင်းဈေး၊ လက်ကျန်၊ Size၊ အရောင် ထည့်နိုင်ခြင်း
- အရောင်းခြင်းတောင်းနှင့် ငွေရှင်းခြင်း
- ငွေရှင်းပြီးပါက stock လျှော့ခြင်း
- အရောင်းမှတ်တမ်းကြည့်ခြင်း
- SharedPreferences ဖြင့် ဖုန်းထဲ local data သိမ်းခြင်း

## ကွန်ပျူတာတွင် APK ထုတ်ရန်
1. Flutter SDK နှင့် Android SDK တပ်ဆင်ပါ။
2. ဒီ folder ထဲ Terminal ဖွင့်ပါ။
3. `flutter create --platforms=android --project-name smk_pos .`
4. `flutter pub get`
5. `flutter build apk --release`
6. APK: `build/app/outputs/flutter-apk/app-release.apk`

## GitHub Actions ဖြင့် APK ထုတ်ရန်
1. Project ကို GitHub repository အသစ်သို့ upload လုပ်ပါ။
2. Actions tab ကိုဖွင့်ပါ။
3. `Build Android APK` workflow ကိုရွေးပြီး `Run workflow` နှိပ်ပါ။
4. အောင်မြင်ပြီးလျှင် workflow run ထဲက Artifacts မှ `smk-pos-release-apk` ကို download လုပ်ပါ။

## အရေးကြီးသော ကန့်သတ်ချက်
ဤသည် စတင်အသုံးပြုနိုင်သော MVP ဖြစ်ပြီး Loyverse ၏ အပြည့်အစုံ clone မဟုတ်ပါ။
လက်ရှိတွင် Bluetooth printer, barcode scanner, cloud sync, multi-user/login,
supplier/purchase, returns, tax, backup/export, detailed profit reports မပါဝင်သေးပါ။
အမှန်တကယ်ဆိုင်တွင် သုံးမီ စမ်းသပ်ပြီး backup နည်းလမ်း ထည့်သွင်းပါ။
