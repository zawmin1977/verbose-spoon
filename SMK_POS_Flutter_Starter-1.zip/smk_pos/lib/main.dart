import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SmkPosApp());
}

class Product {
  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.cost,
    required this.stock,
    this.size = '',
    this.color = '',
  });

  final String id;
  String name;
  double price;
  double cost;
  int stock;
  String size;
  String color;

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'price': price, 'cost': cost,
    'stock': stock, 'size': size, 'color': color,
  };

  factory Product.fromJson(Map<String, dynamic> j) => Product(
    id: j['id'], name: j['name'], price: (j['price'] as num).toDouble(),
    cost: (j['cost'] as num).toDouble(), stock: j['stock'],
    size: j['size'] ?? '', color: j['color'] ?? '',
  );
}

class SaleLine {
  SaleLine(this.name, this.qty, this.price);
  final String name;
  final int qty;
  final double price;
  Map<String, dynamic> toJson() => {'name': name, 'qty': qty, 'price': price};
  factory SaleLine.fromJson(Map<String, dynamic> j) =>
      SaleLine(j['name'], j['qty'], (j['price'] as num).toDouble());
}

class Sale {
  Sale({required this.date, required this.total, required this.lines});
  final DateTime date;
  final double total;
  final List<SaleLine> lines;
  Map<String, dynamic> toJson() => {
    'date': date.toIso8601String(), 'total': total,
    'lines': lines.map((e) => e.toJson()).toList(),
  };
  factory Sale.fromJson(Map<String, dynamic> j) => Sale(
    date: DateTime.parse(j['date']),
    total: (j['total'] as num).toDouble(),
    lines: (j['lines'] as List).map((e) => SaleLine.fromJson(Map<String, dynamic>.from(e))).toList(),
  );
}

class SmkPosApp extends StatefulWidget {
  const SmkPosApp({super.key});
  @override
  State<SmkPosApp> createState() => _SmkPosAppState();
}

class _SmkPosAppState extends State<SmkPosApp> {
  int tab = 0;
  bool loaded = false;
  final List<Product> products = [];
  final List<Sale> sales = [];
  final Map<String, int> cart = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final rawProducts = p.getString('products');
    final rawSales = p.getString('sales');
    if (rawProducts != null) {
      products.addAll((jsonDecode(rawProducts) as List)
          .map((e) => Product.fromJson(Map<String, dynamic>.from(e))));
    } else {
      products.addAll([
        Product(id: 'p1', name: 'T-Shirt', price: 15000, cost: 9000, stock: 12, size: 'M', color: 'အနက်'),
        Product(id: 'p2', name: 'ဘောင်းဘီ', price: 25000, cost: 16000, stock: 8, size: 'L', color: 'အပြာ'),
        Product(id: 'p3', name: 'ဝမ်းဆက်', price: 35000, cost: 22000, stock: 5, size: 'Free Size', color: 'ပန်းရောင်'),
      ]);
    }
    if (rawSales != null) {
      sales.addAll((jsonDecode(rawSales) as List)
          .map((e) => Sale.fromJson(Map<String, dynamic>.from(e))));
    }
    if (mounted) setState(() => loaded = true);
    await _save();
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('products', jsonEncode(products.map((e) => e.toJson()).toList()));
    await p.setString('sales', jsonEncode(sales.map((e) => e.toJson()).toList()));
  }

  double get cartTotal {
    double sum = 0;
    for (final e in cart.entries) {
      final product = products.firstWhere((p) => p.id == e.key);
      sum += product.price * e.value;
    }
    return sum;
  }

  String money(num n) => '${n.toStringAsFixed(0)} ကျပ်';

  void addToCart(Product p) {
    if ((cart[p.id] ?? 0) >= p.stock) {
      _message('လက်ကျန်ပစ္စည်း မလုံလောက်ပါ');
      return;
    }
    setState(() => cart[p.id] = (cart[p.id] ?? 0) + 1);
  }

  void checkout() async {
    if (cart.isEmpty) return;
    final lines = <SaleLine>[];
    for (final e in cart.entries) {
      final p = products.firstWhere((x) => x.id == e.key);
      lines.add(SaleLine('${p.name} ${p.size} ${p.color}'.trim(), e.value, p.price));
      p.stock -= e.value;
    }
    sales.insert(0, Sale(date: DateTime.now(), total: cartTotal, lines: lines));
    setState(() => cart.clear());
    await _save();
    if (mounted) _message('အရောင်းအောင်မြင်ပါသည်');
  }

  void _message(String s) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  }

  Future<void> addProductDialog() async {
    final name = TextEditingController();
    final price = TextEditingController();
    final cost = TextEditingController();
    final stock = TextEditingController(text: '1');
    final size = TextEditingController();
    final color = TextEditingController();
    final formKey = GlobalKey<FormState>();
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('ပစ္စည်းအသစ်ထည့်ရန်'),
      content: Form(key: formKey, child: SingleChildScrollView(child: Column(
        mainAxisSize: MainAxisSize.min, children: [
          _field(name, 'ပစ္စည်းအမည်', requiredField: true),
          _field(price, 'ရောင်းဈေး (ကျပ်)', number: true),
          _field(cost, 'အရင်းဈေး (ကျပ်)', number: true),
          _field(stock, 'လက်ကျန်အရေအတွက်', number: true),
          _field(size, 'Size (ဥပမာ M, L, XL)'),
          _field(color, 'အရောင်'),
        ],
      ))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('မလုပ်တော့ပါ')),
        FilledButton(onPressed: () async {
          if (!formKey.currentState!.validate()) return;
          setState(() => products.add(Product(
            id: DateTime.now().microsecondsSinceEpoch.toString(),
            name: name.text.trim(),
            price: double.tryParse(price.text) ?? 0,
            cost: double.tryParse(cost.text) ?? 0,
            stock: int.tryParse(stock.text) ?? 0,
            size: size.text.trim(), color: color.text.trim(),
          )));
          await _save();
          if (ctx.mounted) Navigator.pop(ctx);
        }, child: const Text('သိမ်းမည်')),
      ],
    ));
  }

  Widget _field(TextEditingController c, String label, {bool number = false, bool requiredField = false}) =>
      Padding(padding: const EdgeInsets.only(bottom: 10), child: TextFormField(
        controller: c, keyboardType: number ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), isDense: true),
        validator: (v) => requiredField && (v == null || v.trim().isEmpty) ? 'ဖြည့်ရန်လိုအပ်သည်' : null,
      ));

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SMK POS',
      theme: ThemeData(colorSchemeSeed: const Color(0xFF176B55), useMaterial3: true),
      home: !loaded ? const Scaffold(body: Center(child: CircularProgressIndicator())) :
        Scaffold(
          appBar: AppBar(title: const Text('SMK POS', style: TextStyle(fontWeight: FontWeight.bold)),
            actions: [Padding(padding: const EdgeInsets.only(right: 12), child: Center(child: Text('အဝတ်အထည်ဆိုင်')))]),
          body: IndexedStack(index: tab, children: [
            _salesPage(), _productsPage(), _historyPage(),
          ]),
          bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.point_of_sale), label: 'အရောင်း'),
              NavigationDestination(icon: Icon(Icons.inventory_2), label: 'ပစ္စည်း'),
              NavigationDestination(icon: Icon(Icons.receipt_long), label: 'မှတ်တမ်း'),
            ]),
          floatingActionButton: tab == 1 ? FloatingActionButton.extended(
            onPressed: addProductDialog, icon: const Icon(Icons.add), label: const Text('ပစ္စည်းထည့်')) : null,
        ),
    );
  }

  Widget _salesPage() => Column(children: [
    Padding(padding: const EdgeInsets.all(12), child: TextField(
      decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ပစ္စည်းရှာရန်', border: OutlineInputBorder()),
      onChanged: (v) => setState(() {}),
    )),
    Expanded(child: ListView.builder(itemCount: products.length, itemBuilder: (ctx, i) {
      final p = products[i];
      return Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), child: ListTile(
        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('${p.size.isEmpty ? '' : 'Size ${p.size}  '} ${p.color} • လက်ကျန် ${p.stock}'),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(money(p.price), style: const TextStyle(fontWeight: FontWeight.bold)),
          TextButton(onPressed: p.stock > 0 ? () => addToCart(p) : null, child: const Text('ထည့်မည်')),
        ]),
      ));
    })),
    Container(color: Theme.of(context).colorScheme.surfaceContainer, padding: const EdgeInsets.all(12), child: Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('ခြင်းတောင်း (${cart.values.fold<int>(0, (a, b) => a + b)} ခု)'),
        Text(money(cartTotal), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ]),
      if (cart.isNotEmpty) ...[
        const SizedBox(height: 6),
        ...cart.entries.map((e) {
          final p = products.firstWhere((x) => x.id == e.key);
          return Row(children: [
            Expanded(child: Text('${p.name} × ${e.value}')),
            IconButton(onPressed: () => setState(() {
              if (e.value <= 1) { cart.remove(e.key); } else { cart[e.key] = e.value - 1; }
            }), icon: const Icon(Icons.remove_circle_outline)),
            IconButton(onPressed: () => addToCart(p), icon: const Icon(Icons.add_circle_outline)),
          ]);
        }),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: checkout, icon: const Icon(Icons.check), label: const Text('ငွေရှင်းမည်'))),
      ],
    ])),
  ]);

  Widget _productsPage() => products.isEmpty
      ? const Center(child: Text('ပစ္စည်းမရှိသေးပါ။ + ကိုနှိပ်ပြီး ထည့်ပါ။'))
      : ListView.builder(itemCount: products.length, itemBuilder: (ctx, i) {
          final p = products[i];
          return ListTile(
            leading: CircleAvatar(child: Text('${i + 1}')),
            title: Text(p.name),
            subtitle: Text('အရင်း ${money(p.cost)} • Size ${p.size} • ${p.color} • လက်ကျန် ${p.stock}'),
            trailing: Text(money(p.price), style: const TextStyle(fontWeight: FontWeight.bold)),
          );
        });

  Widget _historyPage() => sales.isEmpty
      ? const Center(child: Text('အရောင်းမှတ်တမ်း မရှိသေးပါ'))
      : ListView.builder(itemCount: sales.length, itemBuilder: (ctx, i) {
          final s = sales[i];
          return Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), child: ExpansionTile(
            title: Text(money(s.total), style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${s.date.day}/${s.date.month}/${s.date.year}  ${s.date.hour}:${s.date.minute.toString().padLeft(2, '0')}'),
            children: s.lines.map((l) => ListTile(
              dense: true, title: Text(l.name), trailing: Text('${l.qty} × ${money(l.price)}'),
            )).toList(),
          ));
        });
}
